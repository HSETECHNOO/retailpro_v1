const String iconPath = 'assets/icons';
const String imagesPath = 'assets/';

class AppAssets {
  // Icons Path
  static const String pizza = '$iconPath/pizza.png';
}

class Mytexts {
  static String foodname = 'Humber SeaFood';
  static String foodprice = '\$50';
}
