import 'package:flutter/material.dart';

const padding4 = SizedBox(
  height: 4,
  width: 4,
);
const padding5 = SizedBox(
  height: 5,
  width: 5,
);
const padding3 = SizedBox(
  height: 3,
  width: 3,
);
const padding6 = SizedBox(
  height: 6,
  width: 6,
);

const padding8 = SizedBox(
  height: 8,
  width: 8,
);

const padding12 = SizedBox(
  height: 12,
  width: 12,
);
const padding10 = SizedBox(
  height: 10,
  width: 10,
);
const padding15 = SizedBox(
  height: 15,
  width: 15,
);
const padding16 = SizedBox(
  height: 16,
  width: 16,
);
const padding18 = SizedBox(
  height: 18,
  width: 18,
);
const padding20 = SizedBox(
  height: 20,
  width: 20,
);

const padding24 = SizedBox(
  height: 24,
  width: 24,
);
const padding30 = SizedBox(
  height: 30,
  width: 30,
);
const padding32 = SizedBox(
  height: 32,
  width: 32,
);

const padding40 = SizedBox(
  height: 40,
  width: 40,
);
const padding45 = SizedBox(
  height: 45,
  width: 45,
);

const padding48 = SizedBox(
  height: 48,
  width: 48,
);
const padding50 = SizedBox(
  height: 50,
  width: 50,
);
const padding56 = SizedBox(
  height: 56,
  width: 56,
);

const padding64 = SizedBox(
  height: 64,
  width: 64,
);
const padding75 = SizedBox(
  height: 75,
  width: 75,
);
const padding80 = SizedBox(
  height: 80,
  width: 80,
);
const padding85 = SizedBox(
  height: 85,
  width: 85,
);
const padding90 = SizedBox(
  height: 90,
  width: 90,
);
const padding100 = SizedBox(
  height: 100,
  width: 100,
);
const padding120 = SizedBox(
  height: 120,
  width: 120,
);
const padding127 = SizedBox(
  height: 127,
  width: 127,
);
const padding35 = SizedBox(
  height: 35,
  width: 35,
);
const padding152 = SizedBox(
  height: 152,
  width: 152,
);
