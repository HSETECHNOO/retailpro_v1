import 'package:get/get.dart';

class TableorderController extends GetxController {
  final count = 0.obs;

  void increment() => count.value++;
}
