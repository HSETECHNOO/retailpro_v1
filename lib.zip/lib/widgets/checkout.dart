import 'package:flutter/material.dart';
import 'package:retailpro_v1/widgets/details.dart';

class CheckOutPage extends StatelessWidget {
  const CheckOutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const DetailsPage();
  }
}
